package P12;
import javax.swing.*;
import java.awt.event.*;

public class LoginForm {
    JFrame loginFrame = new JFrame("Login");

    JLabel userLabel = new JLabel("Username:");
    JLabel passLabel = new JLabel("Password:");

    JTextField userField = new JTextField();
    JPasswordField passField = new JPasswordField();

    JButton loginButton = new JButton("Login");
    JButton exitButton = new JButton("Exit");

    public LoginForm() {
        loginFrame.setSize(350, 200);
        loginFrame.setLayout(null);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setLocationRelativeTo(null);

        userLabel.setBounds(30, 30, 80, 25);
        userField.setBounds(120, 30, 180, 25);

        passLabel.setBounds(30, 70, 80, 25);
        passField.setBounds(120, 70, 180, 25);

        loginButton.setBounds(50, 120, 100, 30);
        exitButton.setBounds(170, 120, 100, 30);

        loginFrame.add(userLabel);
        loginFrame.add(userField);
        loginFrame.add(passLabel);
        loginFrame.add(passField);
        loginFrame.add(loginButton);
        loginFrame.add(exitButton);

        loginFrame.setVisible(true);

        // Login button logic
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText().trim();
                String password = new String(passField.getPassword()).trim();

                if (username.equals("admin") && password.equals("1234")) {
                    loginFrame.dispose(); // Closes login window
                    new Formll();         // Opens the main application form
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password.");
                }
            }
        });

        // Exit button logic
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Exits the entire application
            }
        });
    }

    // Starting point of program
    public static void main(String[] args) {
        new LoginForm(); // Shows login first
    }
}