package P12;

public class MAIN {
    public static void main(String[] args) {
        new LoginForm(); 
    }
}