package P12;

import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList; // Added import for ArrayList
import java.util.List;     // Added import for List

public class EVENTH extends MouseAdapter {
    Formll mf;
    // Changed from hardcoded if-else statements to a dynamic list of prisoner records.
    // Each String array represents a prisoner: {ID, Name, Gender, Crimes, Officer, CourtDate, IsDangerous}
    private List<String[]> prisonerRecords; // Declares a list to hold prisoner data.

    public EVENTH(Formll f) {
        mf = f;
        initializePrisonerRecords(); // Calls a new method to populate the list.
    }

    // Method to initialize the hardcoded prisoner records into the list.
    private void initializePrisonerRecords() {
        prisonerRecords = new ArrayList<>(); // Initializes the ArrayList.
        // Adding initial hardcoded records to the list.
        // Each record is a String array: {ID, Name, Gender, Crimes, Officer, CourtDate, IsDangerous(boolean as string)}
        prisonerRecords.add(new String[]{"101", "Jahan khan", "Male", "1. Bank robbery", "Officer Tabahi", "Court Date: July 5, 2025", "true"});
        prisonerRecords.add(new String[]{"102", "Alina", "Female", "1. Cybercrime", "Officer Rashid", "Court Date: July 6, 2025", "true"});
        prisonerRecords.add(new String[]{"103", "Babar", "Male", "1. Theft", "Officer Rehman", "Court Date: July 7, 2025", "true"});
        prisonerRecords.add(new String[]{"104", "Sara", "Female", "1. Fraud", "Officer Zia", "Court Date: July 8, 2025", "true"});
        prisonerRecords.add(new String[]{"105", "Usman", "Male", "1. Assault", "Officer Tariq", "Court Date: July 9, 2025", "true"});
        prisonerRecords.add(new String[]{"106", "Fatima", "Female", "1. Kidnapping", "Officer Sana", "Court Date: July 10, 2025", "true"});
        prisonerRecords.add(new String[]{"107", "Ahmed", "Male", "1. Arson", "Officer Bilal", "Court Date: July 11, 2025", "true"});
        prisonerRecords.add(new String[]{"108", "Zoya", "Female", "1. Hacking", "Officer Noman", "Court Date: July 12, 2025", "true"});
        prisonerRecords.add(new String[]{"109", "Hassan", "Male", "1. Smuggling", "Officer Rauf", "Court Date: July 13, 2025", "true"});
        prisonerRecords.add(new String[]{"110", "Mina", "Female", "1. Drug Trafficking", "Officer Shazia", "Court Date: July 14, 2025", "true"});
        prisonerRecords.add(new String[]{"111", "Kamil", "Male", "1. Robbery", "Officer Yousaf", "Court Date: July 15, 2025", "true"});
        prisonerRecords.add(new String[]{"112", "Neha", "Female", "1. Identity Theft", "Officer Sajjad", "Court Date: July 16, 2025", "true"});
        prisonerRecords.add(new String[]{"113", "Talha", "Male", "1. Bribery", "Officer Usama", "Court Date: July 17, 2025", "true"});
        prisonerRecords.add(new String[]{"114", "Rabia", "Female", "1. Murder", "Officer Zubair", "Court Date: July 18, 2025", "true"});
        prisonerRecords.add(new String[]{"115", "Zain", "Male", "1. Espionage", "Officer Faheem", "Court Date: July 19, 2025", "true"});
        prisonerRecords.add(new String[]{"116", "Sana", "Female", "1. Extortion", "Officer Laiba", "Court Date: July 20, 2025", "true"});
        prisonerRecords.add(new String[]{"117", "Omar", "Male", "1. Forgery", "Officer Iqbal", "Court Date: July 21, 2025", "true"});
        prisonerRecords.add(new String[]{"118", "Tania", "Female", "1. Car Theft", "Officer Sarmad", "Court Date: July 22, 2025", "true"});
        prisonerRecords.add(new String[]{"119", "Ali", "Male", "1. Burglary", "Officer Nadeem", "Court Date: July 23, 2025", "true"});
        prisonerRecords.add(new String[]{"120", "Nida", "Female", "1. Money Laundering", "Officer Adnan", "Court Date: July 24, 2025", "true"});
    }

    // New method to add a prisoner record to the list. This is called by PRISONERFORM.
    public void addNewPrisonerRecord(String id, String name, String gender, String officer, String crimes, String courtDate, boolean isDangerous) {
        String newCourtDateFormatted = courtDate.isEmpty() ? "Court Date: To be assigned" : "Court Date: " + courtDate;
        prisonerRecords.add(new String[]{id, name, gender, crimes, officer, newCourtDateFormatted, String.valueOf(isDangerous)});
        JOptionPane.showMessageDialog(null, "New prisoner " + name + " (ID: " + id + ") added to records!");
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == mf.b1) { // "Search Record" button
            String id = mf.getPrisonerID();
            String name = mf.getPrisonerName();

            if (id.isEmpty() || name.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter both ID and Name.");
                return;
            }

            String foundOfficer = "";
            String foundGender = "";
            String foundCrimes = "";
            String foundCourtDate = "";
            boolean foundIsDangerous = false;
            boolean recordFound = false;

            // Iterate through the list of prisoner records to find a match
            for (String[] record : prisonerRecords) {
                // record[0]=ID, record[1]=Name, record[2]=Gender, record[3]=Crimes, record[4]=Officer, record[5]=CourtDate, record[6]=IsDangerous
                if (record[0].equals(id) && record[1].equalsIgnoreCase(name)) { // Compares ID and Name (case-insensitive for name).
                    foundGender = record[2];
                    foundCrimes = record[3];
                    foundOfficer = record[4];
                    foundCourtDate = record[5];
                    foundIsDangerous = Boolean.parseBoolean(record[6]); // Converts the string "true"/"false" back to boolean.
                    recordFound = true;
                    break; // Exit loop once record is found.
                }
            }

            // Set the retrieved data back to the Formll GUI fields.
            mf.setGender(foundGender);
            mf.setOfficer(foundOfficer);
            mf.setCrimes(foundCrimes);
            mf.setLastCourtDate(foundCourtDate);

            if (recordFound) {
                JOptionPane.showMessageDialog(null, "Record found for " + name + ".");
                if (foundIsDangerous) {
                    JOptionPane.showMessageDialog(null, "⚠️️ WARNING: " + name + " is HIGHLY DANGEROUS!");
                }
            } else {
                JOptionPane.showMessageDialog(null, "No record found.");
            }

        } else if (e.getSource() == mf.b2) { // "Clear" button
            mf.clearFields(); // Calls Formll's method to clear all input and output fields.

        } else if (e.getSource() == mf.b3) { // "Check Court Date" button
            // Displays the last retrieved court date from Formll.
            JOptionPane.showMessageDialog(null, mf.getLastCourtDate());

        } else if (e.getSource() == mf.b4) { // "Add New Prisoner" button
            new PRISONERFORM(this); // Creates a new PRISONERFORM, passing the current EVENTH instance to it.

        } else if (e.getSource() == mf.b5) { // "Exit" button
            System.exit(0); // Terminates the application.

        } else if (e.getSource() == mf.b6) { // "View All Records" button
            // Create a new JFrame to display all records with scrolling.
            JFrame allRecordsFrame = new JFrame("All Prisoner Records"); // Creates a new window.
            allRecordsFrame.setSize(550, 450); // Sets the size of the new window.
            allRecordsFrame.setLocationRelativeTo(null); // Centers the new window.
            allRecordsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Closes this window without exiting the app.

            JTextArea recordsTextArea = new JTextArea(); // Creates a multi-line text area.
            recordsTextArea.setEditable(false); // Makes the text area read-only.
            recordsTextArea.setLineWrap(true); // Enables line wrapping.
            recordsTextArea.setWrapStyleWord(true); // Wraps text at word boundaries.

            JScrollPane scrollPane = new JScrollPane(recordsTextArea); // Wraps the text area in a scroll pane.
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); // Always show vertical scrollbar.
            scrollPane.setPreferredSize(new java.awt.Dimension(500, 400)); // Sets a preferred size for the scroll pane.

            StringBuilder sb = new StringBuilder("📋 ALL PRISONER RECORDS:\n\n"); // Uses StringBuilder for efficient string building.
            for (String[] record : prisonerRecords) { // Iterates through each prisoner record in the list.
                // Appends formatted prisoner data to the StringBuilder.
                sb.append("ID: ").append(record[0]).append(" | Name: ").append(record[1]).append(" | Gender: ").append(record[2]).append("\n");
                sb.append("Crime: ").append(record[3]).append("\n");
                sb.append("Officer: ").append(record[4]).append("\n");
                sb.append(record[5]).append("\n"); // Court Date (already includes "Court Date:")
                sb.append("Dangerous: ").append(record[6]).append("\n");
                sb.append("------------------------------\n");
            }
            recordsTextArea.setText(sb.toString()); // Sets the accumulated text to the JTextArea.

            allRecordsFrame.add(scrollPane); // Adds the scroll pane to the new window.
            allRecordsFrame.setVisible(true); // Makes the new window visible.
        }
    }
}