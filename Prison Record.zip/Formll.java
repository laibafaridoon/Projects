package P12;
import javax.swing.*;

public class Formll{ // Declares the public class named Formll. This is the main class for the GUI.
    JFrame f1 = new JFrame("Prisoner Crime Record Lookup"); // Main application window.

    JLabel l1 = new JLabel("Enter Prisoner ID:");
    JLabel l2 = new JLabel("Enter Prisoner Name:");
    JLabel lGender = new JLabel("Gender:");
    JLabel l3 = new JLabel("Officer In Charge:");
    JLabel l4 = new JLabel("Crimes:");

    JTextField t1 = new JTextField(); // Prisoner ID input
    JTextField t2 = new JTextField(); // Prisoner Name input
    JTextField tGender = new JTextField(); // Gender output
    JTextField t3 = new JTextField(); // Officer output
    JTextArea t4 = new JTextArea();   // Crimes output

    JButton b1 = new JButton("Search Record");
    JButton b2 = new JButton("Clear");
    JButton b3 = new JButton("Check Court Date");
    JButton b4 = new JButton("Add New Prisoner");
    JButton b5 = new JButton("Exit");
    JButton b6 = new JButton("View All Records"); // Button to view all records.

    String lastCourtDate = ""; // Stores the last retrieved court date.

    public Formll() { // Constructor for Formll.
        f1.setSize(600, 450); // Sets the size of the frame.
        f1.setLayout(null); // Uses absolute positioning.
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Exits application on close.
        f1.setLocationRelativeTo(null); // Centers the frame.

        // Setting bounds for labels and text fields
        l1.setBounds(30, 30, 140, 30);
        l2.setBounds(30, 70, 140, 30);
        lGender.setBounds(30, 110, 140, 30);
        l3.setBounds(30, 150, 140, 30);
        l4.setBounds(30, 190, 140, 30);

        t1.setBounds(180, 30, 300, 30);
        t2.setBounds(180, 70, 300, 30);
        tGender.setBounds(180, 110, 300, 30);
        t3.setBounds(180, 150, 300, 30);
        t4.setBounds(180, 190, 300, 80);

        tGender.setEditable(false); // Makes gender field read-only.
        t3.setEditable(false); // Makes officer field read-only.
        t4.setEditable(false); // Makes crimes area read-only.
        t4.setLineWrap(true); // Enables line wrapping in crimes area.
        t4.setWrapStyleWord(true); // Wraps at word boundaries.

        // Setting bounds for buttons
        b1.setBounds(30, 290, 140, 30);
        b2.setBounds(180, 290, 140, 30);
        b3.setBounds(330, 290, 180, 30);
        b4.setBounds(30, 340, 180, 30);
        b5.setBounds(330, 340, 80, 30);
        b6.setBounds(430, 340, 140, 30); // Bounds for "View All Records" button.

        // Adding components to the frame
        f1.add(l1); f1.add(t1);
        f1.add(l2); f1.add(t2);
        f1.add(lGender); f1.add(tGender);
        f1.add(l3); f1.add(t3);
        f1.add(l4); f1.add(t4);

        f1.add(b1); f1.add(b2); f1.add(b3);
        f1.add(b4); f1.add(b5); f1.add(b6);

        EVENTH e1 = new EVENTH(this); // Creates EVENTH instance, passing itself (Formll)
        // Adding MouseListeners to buttons
        b1.addMouseListener(e1);
        b2.addMouseListener(e1);
        b3.addMouseListener(e1);
        b4.addMouseListener(e1);
        b5.addMouseListener(e1);
        b6.addMouseListener(e1);

        f1.setVisible(true); // Makes the frame visible.
    }

    // Getter methods for input fields
    String getPrisonerID() {
        return t1.getText().trim();
    }

    String getPrisonerName() {
        return t2.getText().trim();
    }

    // Setter methods for output fields
    void setGender(String gender) {
        tGender.setText(gender);
    }

    void setOfficer(String officer) {
        t3.setText(officer);
    }

    void setCrimes(String crimes) {
        t4.setText(crimes);
    }

    // Getter/Setter for lastCourtDate
    void setLastCourtDate(String date) {
        lastCourtDate = date;
    }

    String getLastCourtDate() {
        return lastCourtDate;
    }

    void clearFields() { // Clears all input and output fields.
        t1.setText("");
        t2.setText("");
        tGender.setText("");
        t3.setText("");
        t4.setText("");
        lastCourtDate = "";
    }

    public static void main(String[] args) { // Main method for directly running Formll.
        new Formll();
    }
}