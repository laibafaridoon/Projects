package P12;
import javax.swing.*;
import java.awt.event.*;
import java.util.List; // Added import for List

public class PRISONERFORM {
    JFrame frame = new JFrame("Add New Prisoner");

    // Existing fields
    JLabel nameLabel = new JLabel("Name:");
    JLabel ageLabel = new JLabel("Age:"); // Age field is present, but not saved in EVENTH's records
    JTextField nameField = new JTextField();
    JTextField ageField = new JTextField();

    // New fields for comprehensive prisoner details
    JLabel idLabel = new JLabel("ID:");
    JLabel genderLabel = new JLabel("Gender:");
    JLabel officerLabel = new JLabel("Officer In Charge:");
    JLabel crimesLabel = new JLabel("Crimes:");
    JLabel courtDateLabel = new JLabel("Court Date:");
    JLabel dangerousLabel = new JLabel("Dangerous Prisoner:");

    JTextField idField = new JTextField();
    JTextField genderField = new JTextField();
    JTextField officerField = new JTextField();
    JTextField courtDateField = new JTextField();
    JTextArea crimesArea = new JTextArea();
    JScrollPane crimesScrollPane = new JScrollPane(crimesArea); // Scroll pane for crimes
    JCheckBox dangerousCheckBox = new JCheckBox(); // Checkbox for 'isDangerous'

    JButton saveButton = new JButton("Save");
    JButton cancelButton = new JButton("Cancel");

    // Reference to EVENTH to call its methods and "save" new data
    private EVENTH eventHandler; // Declares a private instance variable to hold the EVENTH object.

    // Constructor now takes an EVENTH object
    public PRISONERFORM(EVENTH eventHandler) { // Constructor modified to accept an EVENTH object.
        this.eventHandler = eventHandler; // Assigns the passed EVENTH object to the instance variable.

        frame.setSize(400, 500); // Sets the size of the JFrame; increased height for new fields.
        frame.setLayout(null); // Uses absolute positioning for components.
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Closes this window but doesn't exit the application.
        frame.setLocationRelativeTo(null); // Centers the frame on the screen.

        // Set positions for existing fields
        nameLabel.setBounds(30, 30, 120, 25);
        nameField.setBounds(150, 30, 200, 25);

        ageLabel.setBounds(30, 70, 120, 25);
        ageField.setBounds(150, 70, 200, 25); // Age is collected but not stored in the current EVENTH record structure.

        // Set positions for new fields
        idLabel.setBounds(30, 110, 120, 25); // Label for Prisoner ID
        idField.setBounds(150, 110, 200, 25); // Text field for Prisoner ID

        genderLabel.setBounds(30, 150, 120, 25); // Label for Gender
        genderField.setBounds(150, 150, 200, 25); // Text field for Gender

        officerLabel.setBounds(30, 190, 120, 25); // Label for Officer
        officerField.setBounds(150, 190, 200, 25); // Text field for Officer

        crimesLabel.setBounds(30, 230, 120, 25); // Label for Crimes
        crimesScrollPane.setBounds(150, 230, 200, 80); // Position and size for the scrollable text area for crimes.
        crimesArea.setLineWrap(true); // Enables line wrapping for the JTextArea.
        crimesArea.setWrapStyleWord(true); // Wraps text at word boundaries.

        courtDateLabel.setBounds(30, 330, 120, 25); // Label for Court Date
        courtDateField.setBounds(150, 330, 200, 25); // Text field for Court Date

        dangerousLabel.setBounds(30, 370, 120, 25); // Label for Dangerous Prisoner checkbox
        dangerousCheckBox.setBounds(150, 370, 25, 25); // Checkbox for Dangerous Prisoner

        // Adjust button positions
        saveButton.setBounds(50, 420, 100, 30); // Position of the Save button.
        cancelButton.setBounds(180, 420, 100, 30); // Position of the Cancel button.

        // Add all components to the frame
        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(ageLabel);
        frame.add(ageField);

        frame.add(idLabel);
        frame.add(idField);
        frame.add(genderLabel);
        frame.add(genderField);
        frame.add(officerLabel);
        frame.add(officerField);
        frame.add(crimesLabel);
        frame.add(crimesScrollPane); // Add the scroll pane containing the crimes text area.
        frame.add(courtDateLabel);
        frame.add(courtDateField);
        frame.add(dangerousLabel);
        frame.add(dangerousCheckBox);

        frame.add(saveButton);
        frame.add(cancelButton);

        frame.setVisible(true); // Makes the form visible.

        // ActionListener for Save button
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String age = ageField.getText().trim(); // Age is collected but not passed to EVENTH
                String id = idField.getText().trim();
                String gender = genderField.getText().trim();
                String officer = officerField.getText().trim();
                String crimes = crimesArea.getText().trim();
                String courtDate = courtDateField.getText().trim();
                boolean isDangerous = dangerousCheckBox.isSelected(); // Get state of checkbox

                // Basic validation
                if (name.isEmpty() || id.isEmpty() || gender.isEmpty() || officer.isEmpty() || crimes.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all required fields (Name, ID, Gender, Officer, Crimes).");
                    return;
                }

                // Call the method in EVENTH to add the new prisoner record
                // Age is not included as the EVENTH's internal record structure does not have it.
                // Court Date will be formatted by EVENTH if provided.
                eventHandler.addNewPrisonerRecord(id, name, gender, officer, crimes, courtDate, isDangerous);
                frame.dispose(); // Close the "Add New Prisoner" form after saving.
            }
        });

        // ActionListener for Cancel button
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Closes the form without saving.
            }
        });
    }
}